// server.ts
import express from "express";
import { DatabaseSync } from "node:sqlite";
import { randomBytes, scryptSync, timingSafeEqual, createHash } from "node:crypto";
import path from "node:path";
import fs from "node:fs";
import { fileURLToPath } from "node:url";
var app = express();
var port = process.env.API_PORT === void 0 ? 8787 : Number(process.env.API_PORT);
var here = path.dirname(fileURLToPath(import.meta.url));
var dbPath = process.env.DB_FILE || path.join(here, "data", "adelfaqih.sqlite");
fs.mkdirSync(path.dirname(dbPath), { recursive: true });
var db = new DatabaseSync(dbPath);
db.exec("PRAGMA journal_mode = WAL");
db.exec("PRAGMA foreign_keys = ON");
db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT NOT NULL UNIQUE, name TEXT NOT NULL,
  password_hash TEXT NOT NULL, role TEXT NOT NULL DEFAULT 'staff', active INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS sessions (token_hash TEXT PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE, expires_at INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS products (
  id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, category TEXT NOT NULL DEFAULT '', sku TEXT NOT NULL DEFAULT '',
  cost REAL NOT NULL DEFAULT 0, price REAL NOT NULL DEFAULT 0, stock INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS sales (
  id INTEGER PRIMARY KEY AUTOINCREMENT, receipt_no TEXT NOT NULL UNIQUE, customer TEXT NOT NULL DEFAULT '\u0639\u0645\u064A\u0644 \u0646\u0642\u062F\u064A',
  total REAL NOT NULL, payment_method TEXT NOT NULL DEFAULT '\u0646\u0642\u062F\u0627\u064B', user_id INTEGER REFERENCES users(id),
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS sale_items (
  id INTEGER PRIMARY KEY AUTOINCREMENT, sale_id INTEGER NOT NULL REFERENCES sales(id) ON DELETE CASCADE,
  product_id INTEGER REFERENCES products(id) ON DELETE SET NULL, product_name TEXT NOT NULL,
  quantity INTEGER NOT NULL, unit_price REAL NOT NULL, unit_cost REAL NOT NULL DEFAULT 0, line_total REAL NOT NULL
);
`);
var saleItemColumns = db.prepare("PRAGMA table_info(sale_items)").all();
if (!saleItemColumns.some((column) => column.name === "unit_cost")) db.exec("ALTER TABLE sale_items ADD COLUMN unit_cost REAL NOT NULL DEFAULT 0");
app.use(express.json({ limit: "1mb" }));
var hashPassword = (password) => {
  const salt = randomBytes(16).toString("hex");
  return `${salt}:${scryptSync(password, salt, 64).toString("hex")}`;
};
var verifyPassword = (password, stored) => {
  const [salt, hash] = stored.split(":");
  if (!salt || !hash) return false;
  const candidate = scryptSync(password, salt, 64);
  const expected = Buffer.from(hash, "hex");
  return candidate.length === expected.length && timingSafeEqual(candidate, expected);
};
var tokenHash = (token) => createHash("sha256").update(token).digest("hex");
var userView = (row) => ({ id: row.id, username: row.username, name: row.name, role: row.role, active: Boolean(row.active) });
app.get("/api/status", (_req, res) => res.json({ initialized: db.prepare("SELECT COUNT(*) AS n FROM users").get().n > 0 }));
app.post("/api/auth/setup", (req, res) => {
  const { name, username, password } = req.body || {};
  if (db.prepare("SELECT COUNT(*) AS n FROM users").get().n > 0) return res.status(409).json({ error: "\u062A\u0645 \u0625\u0639\u062F\u0627\u062F \u0627\u0644\u0646\u0638\u0627\u0645 \u0645\u0633\u0628\u0642\u0627\u064B\u060C \u0633\u062C\u0644 \u0627\u0644\u062F\u062E\u0648\u0644." });
  if (!name?.trim() || !username?.trim() || !password || password.length < 6) return res.status(400).json({ error: "\u0623\u062F\u062E\u0644 \u0627\u0644\u0627\u0633\u0645 \u0648\u0627\u0633\u0645 \u0627\u0644\u0645\u0633\u062A\u062E\u062F\u0645 \u0648\u0643\u0644\u0645\u0629 \u0645\u0631\u0648\u0631 \u0645\u0646 6 \u0623\u062D\u0631\u0641 \u0639\u0644\u0649 \u0627\u0644\u0623\u0642\u0644." });
  try {
    const result = db.prepare("INSERT INTO users (name, username, password_hash, role) VALUES (?, ?, ?, 'admin')").run(name.trim(), username.trim().toLowerCase(), hashPassword(password));
    issueSession(Number(result.lastInsertRowid), res);
  } catch {
    res.status(409).json({ error: "\u0627\u0633\u0645 \u0627\u0644\u0645\u0633\u062A\u062E\u062F\u0645 \u0645\u0633\u062A\u062E\u062F\u0645 \u0628\u0627\u0644\u0641\u0639\u0644." });
  }
});
function issueSession(userId, res) {
  const token = randomBytes(32).toString("hex");
  db.prepare("INSERT INTO sessions (token_hash, user_id, expires_at) VALUES (?, ?, ?)").run(tokenHash(token), userId, Date.now() + 1e3 * 60 * 60 * 24 * 14);
  const user = db.prepare("SELECT * FROM users WHERE id = ?").get(userId);
  res.json({ token, user: userView(user) });
}
app.post("/api/auth/login", (req, res) => {
  const { username, password } = req.body || {};
  const user = db.prepare("SELECT * FROM users WHERE username = ? AND active = 1").get(String(username || "").trim().toLowerCase());
  if (!user || !password || !verifyPassword(password, user.password_hash)) return res.status(401).json({ error: "\u0627\u0633\u0645 \u0627\u0644\u0645\u0633\u062A\u062E\u062F\u0645 \u0623\u0648 \u0643\u0644\u0645\u0629 \u0627\u0644\u0645\u0631\u0648\u0631 \u063A\u064A\u0631 \u0635\u062D\u064A\u062D\u0629." });
  issueSession(user.id, res);
});
var authenticate = (req, res, next) => {
  const token = String(req.headers.authorization || "").replace(/^Bearer\s+/i, "");
  if (!token) return res.status(401).json({ error: "\u064A\u0631\u062C\u0649 \u062A\u0633\u062C\u064A\u0644 \u0627\u0644\u062F\u062E\u0648\u0644." });
  const session = db.prepare("SELECT users.* FROM sessions JOIN users ON users.id=sessions.user_id WHERE token_hash=? AND expires_at>? AND active=1").get(tokenHash(token), Date.now());
  if (!session) return res.status(401).json({ error: "\u0627\u0646\u062A\u0647\u062A \u0627\u0644\u062C\u0644\u0633\u0629\u060C \u0633\u062C\u0644 \u0627\u0644\u062F\u062E\u0648\u0644 \u0645\u062C\u062F\u062F\u0627\u064B." });
  req.user = session;
  next();
};
app.post("/api/auth/logout", authenticate, (req, res) => {
  db.prepare("DELETE FROM sessions WHERE token_hash=?").run(tokenHash(String(req.headers.authorization).replace(/^Bearer\s+/i, "")));
  res.json({ ok: true });
});
app.use("/api", (req, res, next) => req.path.startsWith("/auth/") || req.path === "/status" ? next() : authenticate(req, res, next));
app.get("/api/me", (req, res) => res.json(userView(req.user)));
app.get("/api/products", (_req, res) => res.json(db.prepare("SELECT * FROM products ORDER BY id DESC").all()));
app.post("/api/products", (req, res) => {
  const { name, category = "", sku = "", cost = 0, price, stock = 0 } = req.body || {};
  if (!String(name || "").trim() || !Number.isFinite(Number(price)) || Number(price) < 0 || Number(stock) < 0) return res.status(400).json({ error: "\u062A\u062D\u0642\u0642 \u0645\u0646 \u0627\u0633\u0645 \u0627\u0644\u0635\u0646\u0641 \u0648\u0627\u0644\u0633\u0639\u0631 \u0648\u0627\u0644\u0643\u0645\u064A\u0629." });
  const result = db.prepare("INSERT INTO products (name, category, sku, cost, price, stock) VALUES (?, ?, ?, ?, ?, ?)").run(String(name).trim(), String(category).trim(), String(sku).trim(), Number(cost) || 0, Number(price), Math.floor(Number(stock)));
  res.status(201).json(db.prepare("SELECT * FROM products WHERE id=?").get(result.lastInsertRowid));
});
app.put("/api/products/:id", (req, res) => {
  const { name, category = "", sku = "", cost = 0, price, stock = 0 } = req.body || {};
  if (!String(name || "").trim() || !Number.isFinite(Number(price)) || Number(stock) < 0) return res.status(400).json({ error: "\u062A\u062D\u0642\u0642 \u0645\u0646 \u0628\u064A\u0627\u0646\u0627\u062A \u0627\u0644\u0635\u0646\u0641." });
  const result = db.prepare("UPDATE products SET name=?, category=?, sku=?, cost=?, price=?, stock=? WHERE id=?").run(String(name).trim(), String(category).trim(), String(sku).trim(), Number(cost) || 0, Number(price), Math.floor(Number(stock)), req.params.id);
  if (!result.changes) return res.status(404).json({ error: "\u0627\u0644\u0635\u0646\u0641 \u063A\u064A\u0631 \u0645\u0648\u062C\u0648\u062F." });
  res.json(db.prepare("SELECT * FROM products WHERE id=?").get(req.params.id));
});
app.delete("/api/products/:id", (req, res) => {
  db.prepare("DELETE FROM products WHERE id=?").run(req.params.id);
  res.json({ ok: true });
});
app.get("/api/sales", (_req, res) => {
  const sales = db.prepare("SELECT sales.*, users.name AS seller FROM sales LEFT JOIN users ON users.id=sales.user_id ORDER BY sales.id DESC LIMIT 100").all();
  res.json(sales.map((s) => ({ ...s, items: db.prepare("SELECT * FROM sale_items WHERE sale_id=?").all(s.id) })));
});
app.post("/api/sales", (req, res) => {
  const { items, customer = "\u0639\u0645\u064A\u0644 \u0646\u0642\u062F\u064A", payment_method = "\u0646\u0642\u062F\u0627\u064B" } = req.body || {};
  if (!Array.isArray(items) || !items.length) return res.status(400).json({ error: "\u0623\u0636\u0641 \u0635\u0646\u0641\u0627\u064B \u0648\u0627\u062D\u062F\u0627\u064B \u0639\u0644\u0649 \u0627\u0644\u0623\u0642\u0644 \u0625\u0644\u0649 \u0627\u0644\u0641\u0627\u062A\u0648\u0631\u0629." });
  const transaction = () => {
    db.exec("BEGIN IMMEDIATE");
    try {
      let total = 0;
      const quantities = /* @__PURE__ */ new Map();
      for (const item of items) {
        const id = Number(item.product_id);
        const quantity = Math.floor(Number(item.quantity));
        if (!Number.isInteger(id) || id < 1 || quantity < 1) throw new Error("\u062A\u0639\u0630\u0631 \u0627\u0644\u0639\u062B\u0648\u0631 \u0639\u0644\u0649 \u0623\u062D\u062F \u0627\u0644\u0623\u0635\u0646\u0627\u0641 \u0623\u0648 \u0623\u0646 \u0627\u0644\u0643\u0645\u064A\u0629 \u063A\u064A\u0631 \u0635\u062D\u064A\u062D\u0629.");
        quantities.set(id, (quantities.get(id) || 0) + quantity);
      }
      const prepared = Array.from(quantities, ([productId, qty]) => {
        const product = db.prepare("SELECT * FROM products WHERE id=?").get(productId);
        if (!product) throw new Error("\u062A\u0639\u0630\u0631 \u0627\u0644\u0639\u062B\u0648\u0631 \u0639\u0644\u0649 \u0623\u062D\u062F \u0627\u0644\u0623\u0635\u0646\u0627\u0641 \u0623\u0648 \u0623\u0646 \u0627\u0644\u0643\u0645\u064A\u0629 \u063A\u064A\u0631 \u0635\u062D\u064A\u062D\u0629.");
        if (product.stock < qty) throw new Error(`\u0627\u0644\u0643\u0645\u064A\u0629 \u0627\u0644\u0645\u062A\u0627\u062D\u0629 \u0645\u0646 ${product.name} \u063A\u064A\u0631 \u0643\u0627\u0641\u064A\u0629.`);
        total += product.price * qty;
        return { product, qty };
      });
      const receipt = `INV-${Date.now().toString().slice(-8)}-${randomBytes(2).toString("hex").toUpperCase()}`;
      const saleId = Number(db.prepare("INSERT INTO sales (receipt_no, customer, total, payment_method, user_id) VALUES (?, ?, ?, ?, ?)").run(receipt, String(customer || "\u0639\u0645\u064A\u0644 \u0646\u0642\u062F\u064A").trim(), total, String(payment_method), req.user.id).lastInsertRowid);
      for (const { product, qty } of prepared) {
        db.prepare("INSERT INTO sale_items (sale_id, product_id, product_name, quantity, unit_price, unit_cost, line_total) VALUES (?, ?, ?, ?, ?, ?, ?)").run(saleId, product.id, product.name, qty, product.price, product.cost, qty * product.price);
        db.prepare("UPDATE products SET stock=stock-? WHERE id=?").run(qty, product.id);
      }
      const created = db.prepare("SELECT * FROM sales WHERE id=?").get(saleId);
      db.exec("COMMIT");
      return created;
    } catch (error) {
      db.exec("ROLLBACK");
      throw error;
    }
  };
  try {
    res.status(201).json(transaction());
  } catch (e) {
    res.status(400).json({ error: e.message || "\u062A\u0639\u0630\u0631 \u0625\u062A\u0645\u0627\u0645 \u0627\u0644\u0628\u064A\u0639." });
  }
});
app.get("/api/dashboard", (_req, res) => {
  const product = db.prepare("SELECT COUNT(*) AS count, COALESCE(SUM(stock),0) AS units, COALESCE(SUM(stock*cost),0) AS inventory_cost FROM products").get();
  const today = db.prepare("SELECT COUNT(s.id) AS count, COALESCE(SUM(s.total),0) AS revenue, COALESCE(SUM(c.cost),0) AS cost FROM sales s LEFT JOIN (SELECT sale_id, SUM(quantity*unit_cost) AS cost FROM sale_items GROUP BY sale_id) c ON c.sale_id=s.id WHERE date(s.created_at)=date('now','localtime')").get();
  const month = db.prepare("SELECT COALESCE(SUM(s.total),0) AS revenue, COALESCE(SUM(c.cost),0) AS cost FROM sales s LEFT JOIN (SELECT sale_id, SUM(quantity*unit_cost) AS cost FROM sale_items GROUP BY sale_id) c ON c.sale_id=s.id WHERE strftime('%Y-%m',s.created_at)=strftime('%Y-%m','now','localtime')").get();
  const recent = db.prepare("SELECT sales.*, users.name AS seller FROM sales LEFT JOIN users ON users.id=sales.user_id ORDER BY id DESC LIMIT 5").all();
  res.json({ products: product.count, units: product.units, inventory_cost: product.inventory_cost, today_sales: today.count, today_revenue: today.revenue, today_profit: today.revenue - today.cost, month_revenue: month.revenue, month_profit: month.revenue - month.cost, low_stock: db.prepare("SELECT COUNT(*) AS n FROM products WHERE stock <= 5").get().n, recent });
});
app.get("/api/users", (req, res) => {
  if (req.user.role !== "admin") return res.status(403).json({ error: "\u0647\u0630\u0647 \u0627\u0644\u0639\u0645\u0644\u064A\u0629 \u0645\u062A\u0627\u062D\u0629 \u0644\u0645\u062F\u064A\u0631 \u0627\u0644\u0646\u0638\u0627\u0645 \u0641\u0642\u0637." });
  res.json(db.prepare("SELECT id, username, name, role, active, created_at FROM users ORDER BY id").all());
});
app.post("/api/users", (req, res) => {
  if (req.user.role !== "admin") return res.status(403).json({ error: "\u0647\u0630\u0647 \u0627\u0644\u0639\u0645\u0644\u064A\u0629 \u0645\u062A\u0627\u062D\u0629 \u0644\u0645\u062F\u064A\u0631 \u0627\u0644\u0646\u0638\u0627\u0645 \u0641\u0642\u0637." });
  const { name, username, password, role = "staff" } = req.body || {};
  if (!name?.trim() || !username?.trim() || !password || password.length < 6) return res.status(400).json({ error: "\u0623\u062F\u062E\u0644 \u0627\u0644\u0627\u0633\u0645 \u0648\u0627\u0633\u0645 \u0627\u0644\u0645\u0633\u062A\u062E\u062F\u0645 \u0648\u0643\u0644\u0645\u0629 \u0645\u0631\u0648\u0631 \u0645\u0646 6 \u0623\u062D\u0631\u0641 \u0639\u0644\u0649 \u0627\u0644\u0623\u0642\u0644." });
  try {
    const result = db.prepare("INSERT INTO users (name, username, password_hash, role) VALUES (?, ?, ?, ?)").run(name.trim(), username.trim().toLowerCase(), hashPassword(password), role === "admin" ? "admin" : "staff");
    res.status(201).json(userView(db.prepare("SELECT * FROM users WHERE id=?").get(result.lastInsertRowid)));
  } catch {
    res.status(409).json({ error: "\u0627\u0633\u0645 \u0627\u0644\u0645\u0633\u062A\u062E\u062F\u0645 \u0645\u0633\u062A\u062E\u062F\u0645 \u0628\u0627\u0644\u0641\u0639\u0644." });
  }
});
app.put("/api/users/:id/password", (req, res) => {
  const id = Number(req.params.id);
  const { current_password, password } = req.body || {};
  if (id !== req.user.id && req.user.role !== "admin") return res.status(403).json({ error: "\u063A\u064A\u0631 \u0645\u0633\u0645\u0648\u062D." });
  if (!password || password.length < 6) return res.status(400).json({ error: "\u064A\u062C\u0628 \u0623\u0646 \u062A\u062A\u0643\u0648\u0646 \u0643\u0644\u0645\u0629 \u0627\u0644\u0645\u0631\u0648\u0631 \u0627\u0644\u062C\u062F\u064A\u062F\u0629 \u0645\u0646 6 \u0623\u062D\u0631\u0641 \u0639\u0644\u0649 \u0627\u0644\u0623\u0642\u0644." });
  const user = db.prepare("SELECT * FROM users WHERE id=?").get(id);
  if (!user) return res.status(404).json({ error: "\u0627\u0644\u0645\u0633\u062A\u062E\u062F\u0645 \u063A\u064A\u0631 \u0645\u0648\u062C\u0648\u062F." });
  if (id === req.user.id && !verifyPassword(String(current_password || ""), user.password_hash)) return res.status(400).json({ error: "\u0643\u0644\u0645\u0629 \u0627\u0644\u0645\u0631\u0648\u0631 \u0627\u0644\u062D\u0627\u0644\u064A\u0629 \u063A\u064A\u0631 \u0635\u062D\u064A\u062D\u0629." });
  db.prepare("UPDATE users SET password_hash=? WHERE id=?").run(hashPassword(password), id);
  res.json({ ok: true });
});
app.put("/api/users/:id/active", (req, res) => {
  if (req.user.role !== "admin") return res.status(403).json({ error: "\u0647\u0630\u0647 \u0627\u0644\u0639\u0645\u0644\u064A\u0629 \u0645\u062A\u0627\u062D\u0629 \u0644\u0645\u062F\u064A\u0631 \u0627\u0644\u0646\u0638\u0627\u0645 \u0641\u0642\u0637." });
  if (Number(req.params.id) === req.user.id) return res.status(400).json({ error: "\u0644\u0627 \u064A\u0645\u0643\u0646\u0643 \u0625\u064A\u0642\u0627\u0641 \u062D\u0633\u0627\u0628\u0643 \u0627\u0644\u062D\u0627\u0644\u064A." });
  db.prepare("UPDATE users SET active=? WHERE id=?").run(req.body.active ? 1 : 0, req.params.id);
  res.json({ ok: true });
});
if (process.env.NODE_ENV === "production") app.use(express.static(process.env.APP_DIST || path.join(here, "dist")));
var httpServer = app.listen(port, process.env.API_HOST || "127.0.0.1");
httpServer.on("listening", () => {
  const address = httpServer.address();
  console.log(`Adel Alfaqih API listening on ${address && typeof address !== "string" ? address.port : port}`);
});
httpServer.on("close", () => db.close());
export {
  httpServer
};
